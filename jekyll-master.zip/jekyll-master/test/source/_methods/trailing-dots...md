---
title: Ellipsis Path
---
